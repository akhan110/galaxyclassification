import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  HttpOverrides.global = MyHttpOverrides(); // Bypass SSL errors
  runApp(ImageUploadApp());
}

// Bypass SSL Certificate Errors (For Development Only)
class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}

class ImageUploadApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ImageUploadScreen(),
    );
  }
}

class ImageUploadScreen extends StatefulWidget {
  @override
  _ImageUploadScreenState createState() => _ImageUploadScreenState();
}

class _ImageUploadScreenState extends State<ImageUploadScreen> {
  File? _selectedImage;
  String _responseText = "Upload an image to see response";
  bool _isLoading = false; // To track loading state
  final ImagePicker _picker = ImagePicker();

  // Function to pick an image
  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  // Function to upload image with loading indicator
  Future<void> _uploadImage() async {
    if (_selectedImage == null) {
      setState(() {
        _responseText = "No image selected!";
      });
      return;
    }

    setState(() {
      _isLoading = true;
    });

    String apiUrl = "https://670b-35-190-183-127.ngrok-free.app/predict/";
    List<int> imageBytes = await _selectedImage!.readAsBytes();
    String base64Image = base64Encode(imageBytes);

    Map<String, dynamic> payload = {"image_base64": base64Image};
    String jsonPayload = jsonEncode(payload);

    try {
      HttpClient client = HttpClient();
      client.badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;

      HttpClientRequest request = await client.postUrl(Uri.parse(apiUrl));
      request.headers.set(HttpHeaders.contentTypeHeader, "application/json");
      request.add(utf8.encode(jsonPayload));

      HttpClientResponse response = await request.close();
      String responseBody = await response.transform(utf8.decoder).join();

      setState(() {
        if (response.statusCode == 200) {
          Map<String, dynamic> jsonResponse = jsonDecode(responseBody);
          List<dynamic> labels = jsonResponse["detected_labels"];
          _responseText =
              labels.isNotEmpty ? labels.first.toString() : "No label detected";
        } else {
          _responseText = "Error ${response.statusCode}: $responseBody";
        }
      });
    } catch (e) {
      setState(() {
        _responseText = "Failed to upload: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "GALAXY CLASSIFICATION",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 44, 4, 51),
      ),
      body: Stack(
        children: [
          // Background Image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("asset/backgroun.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          // Foreground Content
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 1),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Image Container
                    Expanded(
                      flex: 2,
                      child: Column(
                        children: [
                          Container(
                            height: 600,
                            width: double.infinity,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.white, width: 2),
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.black.withOpacity(.7),
                            ),
                            child: _selectedImage != null
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.file(_selectedImage!,
                                        fit: BoxFit.cover),
                                  )
                                : const Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.error,
                                          size: 80, color: Colors.grey),
                                      Text(
                                        "No Image Selected",
                                        style: TextStyle(
                                            color: Colors.white, fontSize: 20),
                                      )
                                    ],
                                  ),
                          ),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ElevatedButton(
                                onPressed: _pickImage,
                                child: const Text(
                                  "Pick Image",
                                  style: TextStyle(color: Colors.black),
                                ),
                              ),
                              const SizedBox(width: 20),
                              ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    _selectedImage = null;
                                  });
                                },
                                child: const Text("Clear Image",
                                    style: TextStyle(color: Colors.red)),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              ElevatedButton(
                                onPressed: _uploadImage,
                                child: _isLoading
                                    ? const SizedBox(
                                        width: 20,
                                        height: 20,
                                        child: CircularProgressIndicator(
                                          color: Colors.red,
                                        ))
                                    : const Text("Submit Image",
                                        style: TextStyle(color: Colors.teal)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 20),
                    // Text Container
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          height: 60,
                          child: Center(
                            child: _isLoading
                                ? const CircularProgressIndicator()
                                : Text.rich(
    TextSpan(
    children: [
      TextSpan(
        text: "Detected Galaxy Type:   ", 
        style: TextStyle(
          fontSize: 22, 
          fontWeight: FontWeight.bold, 
          color: Colors.pink, // Color for the label
        ),
      ),
      TextSpan(
        text: _responseText.toUpperCase(), 
        style: TextStyle(
          fontSize: 22, 
          fontWeight: FontWeight.bold, 
          color: Colors.black, // Color for the detected type
        ),
      ),
    ],
  ),
  textAlign: TextAlign.center,
) 

                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
