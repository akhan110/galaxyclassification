package com.example.astrolocation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
